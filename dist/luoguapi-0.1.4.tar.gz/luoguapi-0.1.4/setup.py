from setuptools import setup
setup(name='luoguapi',
      version='0.1.4',
      description='An API Client for Luogu',
      author='CodingOIer',
      author_email='codingoier-project@outlook.com',
      )
